#!/bin/bash
# Eagle updater script
# The purpose of this script is to complete the firmware update
# process for the Ernest Sports Eagle. This consists of several steps:
#	1. Check if a file called "eagleUpdated" exists
#	2. If it exists, then rename "eagle" to "eagleBackup"
#	3. Calculate the checksum of "eagleUpdated" and compare it
#	   to a known value.
#	4 (a). If the checksums match, then rename "eagleUpdated" to "eagle"
#	   and run that new executable
#	4 (b). If the checksums do not match, then rename "eagleBackup"
#	       back to "eagle" and run the old executable
#	5. Exit

# Return codes:
# 0 = component updated
# 1 = component failed verification or install
# 2 = component was not included, or was already current

# Start the update process with the main executable
function updateMainExecutable() {
	if [[ -e eagleUpdated ]]; then
		echo "Main executable: update file found."
		
		# Make a backup of the current executable
		mv eagle eagleBackup
		
		# Read the hash value from the hash file
		knownHash=$(dd if=eagleHash.txt bs=1 count=64 skip=0 2>/dev/null)
		
		# Calculate the hash of the downloaded executable
		calcHashNew=$(sha256sum eagleUpdated)
		calcHashNew=${calcHashNew:0:64}
		
		# Compare the hashes. If they match
		# then the file was downloaded correctly
		# so we can next check if it is a new file
		if [[ "$calcHashNew" = "$knownHash" ]]; then
			echo "Main executable: verification passed."
			
			# Calculate the hash of the current executable
			calcHashOld=$(sha256sum eagleBackup)
			calcHashOld=${calcHashOld:0:64}
			
			# If the old and new hashes match then
			# we can update the executable
			if [[ "$calcHashNew" != "$calcHashOld" ]]; then
				echo "Main executable: installing update."
				mv eagleUpdated eagle
				sudo chmod +x eagle
				rm eagleBackup
				return 0
						
			else
				echo "Main executable: already current; no update needed."
				
				# Revert to the previous executable
				# and delete the downloaded file
				# if the hashes match
				mv eagleBackup eagle
				rm eagleUpdated
				return 2
			fi
		
		else
			echo "Main executable: verification failed; keeping current file."
			mv eagleBackup eagle
			rm eagleUpdated
			return 1
		fi
	
	else
		echo "Main executable: update file not included; skipping."
		return 2
	fi
}

# Update the BLE app
function updateBLEApp() {
	if [[ -e ble-wifi-updated ]]; then
		echo "BLE app: update file found."
		
		# Read the hash of the new app from the hash file
		knownHash=$(dd if=eagleHash.txt bs=1 count=64 skip=65 2>/dev/null)
		
		# Calculate the hash of the downloaded app
		calcHashNew=$(sha256sum ble-wifi-updated)
		calcHashNew=${calcHashNew:0:64}
		
		# Compare the hashes. If they match
		# then the file was downloaded correctly
		# so we can next check if it is a new file
		if [[ "$calcHashNew" = "$knownHash" ]]; then
			echo "BLE app: verification passed."
			
			# Calculate the hash of the current app if it exists
			calcHashOld=""
			if [[ -e ble-wifi-config ]]; then
				calcHashOld=$(sha256sum ble-wifi-config)
				calcHashOld=${calcHashOld:0:64}
			fi
			
			# If the hashes do not match then update the app
			if [[ "$calcHashNew" != "$calcHashOld" ]]; then
				echo "BLE app: installing update."
				
				sudo systemctl stop ble-wifi-config
				rm -f ble-wifi-config
				mv ble-wifi-updated ble-wifi-config
				sudo chmod +x ble-wifi-config
				return 0
			
			else
				echo "BLE app: already current; no update needed."
				rm ble-wifi-updated
				return 2
			fi
		
		else
			echo "BLE app: verification failed; skipping update."
			rm ble-wifi-updated
			return 1
		fi
	
	else
		echo "BLE app: update file not included; skipping."
		return 2
	fi
}

# Update the main script
function updateMainScript() {
	if [[ -e eagleUpdated.sh ]]; then
		echo "Main script: update file found."
		
		# Read the hash out of the hash file
		knownHash=$(dd if=eagleHash.txt bs=1 count=64 skip=130 2>/dev/null)
		
		# Calculate the hash of the file
		calcHashNew=$(sha256sum eagleUpdated.sh)
		calcHashNew=${calcHashNew:0:64}
		
		# Compare the hashes. If they match then
		# the file was downloaded correctly.
		if [[ "$calcHashNew" = "$knownHash" ]]; then
			echo "Main script: verification passed."
			
			# Calculate the hash of the current main script
			calcHashOld=$(sha256sum eagle.sh)
			calcHashOld=${calcHashOld:0:64}
			
			# If the hashes do not match then update the main script
			if [[ "$calcHashNew" != "$calcHashOld" ]]; then
				echo "Main script: installing update."
				
				mv eagleUpdated.sh eagle.sh
				sudo chmod +x eagle.sh
				return 0
			
			else
				echo "Main script: already current; no update needed."
				rm eagleUpdated.sh
				return 2
			fi
			
		else
			echo "Main script: verification failed; skipping update."
			rm eagleUpdated.sh
			return 1
		fi
	
	else
		echo "Main script: update file not included; skipping."
		return 2
	fi
}

function updateScriptFile() {
	local currentFile="$1"
	local updatedFile="$2"
	local scriptName="$3"
	local hashOffset="$4"

	if [[ -e "$updatedFile" ]]; then
		echo "$scriptName: update file found."

		# Read the hash out of the hash file
		knownHash=$(dd if=eagleHash.txt bs=1 count=64 skip="$hashOffset" 2>/dev/null)

		# Calculate the hash of the file
		calcHashNew=$(sha256sum "$updatedFile")
		calcHashNew=${calcHashNew:0:64}

		# Compare the hashes. If they match then
		# the file was downloaded correctly.
		if [[ "$calcHashNew" = "$knownHash" ]]; then
			echo "$scriptName: verification passed."

			# Calculate the hash of the current script if it exists
			calcHashOld=""
			if [[ -e "$currentFile" ]]; then
				calcHashOld=$(sha256sum "$currentFile")
				calcHashOld=${calcHashOld:0:64}
			fi

			# If the hashes do not match then update the script
			if [[ "$calcHashNew" != "$calcHashOld" ]]; then
				echo "$scriptName: installing update."

				mv "$updatedFile" "$currentFile"
				sudo chmod +x "$currentFile"
				return 0

			else
				echo "$scriptName: already current; no update needed."
				rm "$updatedFile"
				return 2
			fi

		else
			echo "$scriptName: verification failed; skipping update."
			rm "$updatedFile"
			return 1
		fi

	else
		echo "$scriptName: update file not included; skipping."
		return 2
	fi
}

updateMainExecutable
retVal1=$?

updateBLEApp
retVal2=$?

updateMainScript
retVal3=$?

updateScriptFile "media_setting_rpi5.sh" "media_setting_rpi5_updated.sh" "media settings script" 195
retVal4=$?

updateScriptFile "find_entity.sh" "find_entity_updated.sh" "entity finder script" 260
retVal5=$?

# If any component failed verification or install, report failure.
# If at least one component changed and none failed, report success.
# Otherwise the package was valid, but everything was already current.
if [[ $retVal1 = 1 || $retVal2 = 1 || $retVal3 = 1 || $retVal4 = 1 || $retVal5 = 1 ]]; then
	echo "Firmware update result: failed; one or more components did not verify or install."
	exit 1
elif [[ $retVal1 = 0 || $retVal2 = 0 || $retVal3 = 0 || $retVal4 = 0 || $retVal5 = 0 ]]; then
	echo "Firmware update result: success; one or more components were updated."
	exit 0
else
	echo "Firmware update result: no changes; all included components were already current."
	exit 2
fi
