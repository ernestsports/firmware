#!/bin/bash
# Eagle updater script
# The purpose of this script is to complete the firmware update
# process for the Ernest Sports Eagle. This consists of several steps:
#	1. Check if a file called "eagleUpdated" exists
#	2. If it exists, then rename "eagle" to "eagleBackup"
#	3. Calculate the checksum of "eagleUpdated" and compare it
#	   to a known value.
#	4 (a). If the checksums match, then rename "eagleUpdated" to "eagle"
#	   and run that new executable
#	4 (b). If the checksums do not match, then rename "eagleBackup"
#	       back to "eagle" and run the old executable
#	5. Exit

# Start the update process with the main executable
function updateMainExecutable() {
	if [[ -e eagleUpdated ]]; then
		echo "New Eagle executable found"
		
		# Make a backup of the current executable
		mv eagle eagleBackup
		
		# Read the hash value from the hash file
		knownHash=$(dd if=eagleHash.txt bs=1 count=64 skip=0 2>/dev/null)
		
		# Calculate the hash of the downloaded executable
		calcHashNew=$(sha256sum eagleUpdated)
		calcHashNew=${calcHashNew:0:64}
		
		# Compare the hashes. If they match
		# then the file was downloaded correctly
		# so we can next check if it is a new file
		if [[ "$calcHashNew" = "$knownHash" ]]; then
			echo "Downloaded executable verifies"
			
			# Calculate the hash of the current executable
			calcHashOld=$(sha256sum eagleBackup)
			calcHashOld=${calcHashOld:0:64}
			
			# If the old and new hashes match then
			# we can update the executable
			if [[ "$calcHashNew" != "$calcHashOld" ]]; then
				echo "Updating main executable"
				mv eagleUpdated eagle
				sudo chmod +x eagle
				rm eagleBackup
				return 0
						
			else
				echo "Main executable not updated"
				
				# Revert to the previous executable
				# and delete the downloaded file
				# if the hashes match
				mv eagleBackup eagle
				rm eagleUpdated
				return 1
			fi
		
		else
			echo "Downloaded executable verification failed. Skipping."
			mv eagleBackup eagle
			rm eagleUpdated
			return 1
		fi
	
	else
		echo "New executable not found. Skipping."
		mv eagleBackup eagle
		return 1
	fi
}

# Update the BLE app
function updateBLEApp() {
	if [[ -e ble-wifi-updated ]]; then
		echo "New BLE app found"
		
		# Read the hash of the new app from the hash file
		knownHash=$(dd if=eagleHash.txt bs=1 count=64 skip=65 2>/dev/null)
		
		# Calculate the hash of the downloaded app
		calcHashNew=$(sha256sum ble-wifi-updated)
		calcHashNew=${calcHashOld:0:64}
		
		# Compare the hashes. If they match
		# then the file was downloaded correctly
		# so we can next check if it is a new file
		if [[ "$calcHashNew" = "$knownHash" ]]; then
			echo "BLE app verified"
			
			# Calculate the hash of the current app
			calcHashOld=$(sha256sum ble-wifi-config)
			calcHashOld=${calcHashNew:0:64}
			
			# If the hashes do not match then update the app
			if [[ "$calcHashNew" != "$calcHashOld" ]]; then
				echo "Updating BLE app"
				
				sudo systemctl stop ble-wifi-config
				rm ble-wifi-config
				mv ble-wifi-config-updated ble-wifi-config
				return 0
			
			else
				echo "BLE app not updated"
				rm ble-wifi-updated
				return 1
			fi
		
		else
			echo "BLE app verification failed. Skipping."
			rm ble-wifi-updated
			return 1
		fi
	
	else
		echo "New BLE app not found. Skipping."
		return 1
	fi
}

# Update the main script
function updateMainScript() {
	if [[ -e eagleUpdated.sh ]]; then
		echo "New main script found."
		
		# Read the hash out of the hash file
		knownHash=$(dd if=eagleHash.txt bs=1 count=64 skip=130 2>/dev/null)
		
		# Calculate the hash of the file
		calcHashNew=$(sha256sum eagleUpdated.sh)
		calcHashNew=${calcHashNew:0:64}
		
		# Compare the hashes. If they match then
		# the file was downloaded correctly.
		if [[ "$calcHashNew" = "$knownHash" ]]; then
			echo "Main script verified correctly."
			
			# Calculate the hash of the current main script
			calcHashOld=$(sha256sum eagle.sh)
			calcHashOld=${calcHashOld:0:64}
			
			# If the hashes do not match then update the main script
			if [[ "$calcHashNew" != "$calcHashOld" ]]; then
				echo "Updating main script"
				
				mv eagleUpdated.sh eagle.sh
				return 0
			
			else
				echo "Main script not updated"
				rm eagleUpdated.sh
				return 1
			fi
			
		else
			echo "Main script verification failed. Skipping."
			rm eagleUpdated.sh
			return 1
		fi
	
	else
		echo "new main script not found. Skipping."
		return 1
	fi
}

updateMainExecutable
retVal1=$?

updateBLEApp
retVal2=$?

updateMainScript
retVal3=$?

# If one of the updates succeeded then we can return 0
# Otherwise if they all failed we return 1
if [[ $retVal1 = 0 ]]; then
	exit 0

elif [[ $retVal2 = 0 ]]; then
	exit 0

elif [[ $retVal3 = 0 ]]; then
	exit 0

else
	exit 1
fi
