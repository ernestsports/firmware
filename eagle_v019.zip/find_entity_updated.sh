#!/bin/bash

find_entity_device(){
    local entity_name="$1"
    local entity_id="$2"

    for media_device in /dev/media*; do
        #echo "Checking $media_device..."
        entity_info=$(media-ctl -d $media_device -p 2>/dev/null | grep "$entity_name $entity_id-003b")
        if [ -n "$entity_info" ]; then
            g_video_device=$(media-ctl -e rp1-cfe-csi2_ch0 -d $media_device)
            g_video_subdevice=$(media-ctl -e "$entity_name $entity_id-003b" -d $media_device)
            echo "$entity_id"
            echo "$g_video_device"
            echo "$g_video_subdevice"
            echo "$media_device"
            echo "$entity_name"
        fi
    done
}

# Pi 5 kernels prior to the newer RP1 I2C numbering expose CAM1/CAM0 on
# buses 4/6; newer kernels expose the same ports on buses 11/10.
find_entity_device "mvcam" "4"
find_entity_device "mvcam" "6"
find_entity_device "mvcam" "11"
find_entity_device "mvcam" "10"

# find_entity_device "veyecam2m" "4"
# find_entity_device "veyecam2m" "6"

# find_entity_device "csimx307" "4"
# find_entity_device "csimx307" "6"

# find_entity_device "cssc132" "4"
# find_entity_device "cssc132" "6"
